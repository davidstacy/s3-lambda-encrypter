


Lambda S3 Object Encrypter



Use case heavily inspired by this tutorial:  http://docs.aws.amazon.com/lambda/latest/dg/with-s3-example.html

Code copied and modified from:  https://github.com/eleven41/aws-lambda-encrypt-s3-objects/blob/master/index.js







